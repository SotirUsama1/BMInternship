# Docker Run Command - Flag Explanation

Command used:
`docker run --name hello-test -p 3040:80 hello-world`

`--name hello-test`
Names the container "hello-test" so it can be reused, restarted, or removed easily.

`-p 3040:80`
Maps port 80 in the container to port 3040 on the host machine.

`hello-world`
The image name. It simply prints a confirmation message and exits.
