# Guided Lab: Replicating a Docker Compose Application Locally

## Introduction

This guided lab is designed to help you replicate a simple Flask web application, containerized with Docker and orchestrated using Docker Compose, on your local machine. By following these instructions, you will gain hands-on experience with Docker, Docker Compose, and the process of setting up a multi-service application environment. This lab is estimated to take approximately 20 minutes to complete.

## Learning Objectives

Upon completion of this lab, you will be able to:

- Understand the basic structure of a Docker Compose project.
- Build Docker images from a Dockerfile.
- Run multi-container applications using Docker Compose.
- Verify the functionality of a containerized web application.
- Troubleshoot common issues encountered during Docker Compose setup.

## Prerequisites

Before you begin this lab, please ensure you have the following software installed on your system:

- **Docker Desktop:** This includes Docker Engine, Docker CLI, Docker Compose, and Kubernetes. You can download it from the official Docker website [1].
- **Git:** A version control system used to clone the project repository. You can download it from the official Git website [2].
- **A text editor:** Such as Visual Studio Code, Sublime Text, or Notepad++, for viewing and potentially editing code files.

### Verifying Your Installation

To ensure Docker and Git are correctly installed, open your terminal or command prompt and run the following commands:

```bash
docker --version
docker compose version
git --version
```

If the commands return version numbers without errors, you are ready to proceed.

## Lab Setup

To begin, you will need to obtain the lab files. In a real-world scenario, you would clone a Git repository. For this lab, we will assume the files (`Dockerfile`, `docker-compose.yml`, `app.py`, `requirements.txt`) are provided to you directly in a folder named `my-compose-app`.

### Step 1: Create the Project Directory

Create a new directory on your local machine where you will place the lab files. You can do this using your file explorer or by running the following command in your terminal:

```bash
mkdir my-compose-app
cd my-compose-app
```

### Step 2: Place the Lab Files

Ensure the `Dockerfile`, `docker-compose.yml`, `app.py`, and `requirements.txt` files are placed inside the `my-compose-app` directory you just created.

## Lab Instructions

Now that your environment is set up and the lab files are in place, you can proceed with replicating the Docker Compose application.

### Step 3: Build and Run the Application

Navigate to the `my-compose-app` directory in your terminal (if you are not already there) and execute the following Docker Compose command to build the Docker image and start the services defined in `docker-compose.yml`:

```bash
docker compose up --build -d
```

- `docker compose up`: This command starts the services defined in your `docker-compose.yml` file.
- `--build`: This flag tells Docker Compose to build the images before starting the containers. This is crucial for our `web` service, which uses a `Dockerfile`.
- `-d`: This flag runs the containers in detached mode, meaning they will run in the background, and you will regain control of your terminal.

### Step 4: Verify the Application

Once the services are up and running, you can verify that the web application is accessible. Open your web browser and navigate to:

`http://localhost:5000`

You should see a simple message: "Hello, Docker Compose!" This confirms that your Flask application is running correctly within its Docker container and is accessible via the exposed port.

### Step 5: View Container Logs

To see the output from your running containers, you can use the `docker compose logs` command. This is useful for debugging and monitoring your application.

```bash
docker compose logs
```

This command will display the logs from all services defined in your `docker-compose.yml` file. You should see output from both the `web` service (your Flask app) and the `redis` service.

### Step 6: Stop and Remove the Application

When you are finished with the lab, it's good practice to stop and remove the Docker Compose application and its associated resources to free up system resources. Navigate back to the `my-compose-app` directory in your terminal and run:

```bash
docker compose down
```

- `docker compose down`: This command stops the running containers and removes the containers, networks, and volumes that were created by `docker compose up`.

## Troubleshooting

- **Port already in use:** If you encounter an error indicating that port 5000 is already in use, it means another application on your machine is using that port. You can either stop the other application or change the port mapping in your `docker-compose.yml` file (e.g., `"8000:5000"`).
- **`docker compose` command not found:** Ensure Docker Desktop is installed and running, and that Docker Compose is included in your system's PATH. Restarting your terminal or computer might resolve this.
- **Application not accessible:** Double-check that your Docker containers are running (`docker ps`) and that there are no errors in the logs (`docker compose logs`). Also, ensure your firewall is not blocking access to port 5000.

## Conclusion

Congratulations! You have successfully replicated a Docker Compose application locally. You've learned how to set up a multi-service environment, build and run containers, and perform basic verification and cleanup. This foundational knowledge is crucial for developing and deploying containerized applications.

## References

[1] Docker Desktop: <https://www.docker.com/products/docker-desktop/>

[2] Git: <https://git-scm.com/downloads>
