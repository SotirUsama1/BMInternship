# Docker Lifecycle & Clean-up Report

## Objective
Demonstrate the full lifecycle of a Docker container (create → start → stop → remove) and clean up unused images using `docker image prune`. Record and compare disk usage before and after clean-up.

---

## 1. Disk Usage Before

Command:
```bash
docker system df
```

Output:
```
TYPE            TOTAL     ACTIVE    SIZE      RECLAIMABLE
Images          7         4         5.086GB   4.261GB (83%)
Containers      4         0         2.998MB   2.998MB (100%)
Local Volumes   4         2         1.426GB   445.3MB (31%)
Build Cache     17        0         2.097MB   2.097MB
```

---

## 2. Create & Start Container

Command:
```bash
docker run -dit --name lifecycle-test alpine sh
```

Output:
```
c1ce44dfcb6c9b9b04504bb63976951d0dc1a066cc52f9df5269505574953fd8
```

---

## 3. Stop Container

Command:
```bash
docker stop lifecycle-test
```

Output:
```
lifecycle-test
```

---

## 4. Remove Container

Command:
```bash
docker rm lifecycle-test
```

Output:
```
lifecycle-test
```

---

## 5. List Images Before Clean-up

Command:
```bash
docker images
```

Output:
```
REPOSITORY       TAG       IMAGE ID       CREATED         SIZE
<none>           <none>    7e6e74de69ff   2 days ago      1.67GB
alpine           latest    4bcff63911fc   10 days ago     12.8MB
nginx            latest    f5c017fb33c6   10 days ago     279MB
kicbase/stable   v0.0.47   8311be96a0a8   2 months ago    1.86GB
kicbase/stable   <none>    6ed579c9292b   2 months ago    1.86GB
mysql            latest    b9d8b7ec6e6a   3 months ago    1.17GB
busybox          latest    f85340bf132a   10 months ago   6.55MB
```

---

## 6. Clean Up Unused Images

Command:
```bash
docker image prune -f
```

Output:
```
Deleted Images:
untagged: sha256:7e6e74de69ff071faee42ed44c540d78415278abbd4530f41daf751f53b01b32
deleted: sha256:7e6e74de69ff071faee42ed44c540d78415278abbd4530f41daf751f53b01b32
deleted: sha256:a2b7954f4f4f628ea6e21a903edda8c762c985f07956a5ad4aa7fe7c6a2b3fae
deleted: sha256:ae30ff45f37ad2946adb86d09c90476c29af9bcdfbc229e915e018aae9cd9c60
deleted: sha256:6508415ec76d9e459e06274b6b9c15eb08fce49ff193874a4bf1524b51fca69c
deleted: sha256:c0b23e18f35f56d6e769deb411393b8349ea496530198f51d86b8c113636ac32
deleted: sha256:76236d667e20ec7a22371ea64a7fbb58d6e9ff4cec944d8fe88818ecd6a90fb9
untagged: sha256:8311be96a0a8e5219ed660ff20023f67f65becadacb6dec6b62356dcdd86efeb

Total reclaimed space: 13.13kB
```

---

## 7. Disk Usage After

Command:
```bash
docker system df
```

Output:
```
TYPE            TOTAL     ACTIVE    SIZE      RECLAIMABLE
Images          6         4         4.595GB   3.77GB (82%)
Containers      4         0         2.998MB   2.998MB (100%)
Local Volumes   4         2         1.426GB   445.3MB (31%)
Build Cache     17        0         1.673GB   1.673GB
```

---

## Summary

- One dangling image and part of `kicbase` were successfully deleted.
- Disk space reduced from **5.086GB → 4.595GB** for images.
- `docker image prune` helped reclaim unnecessary storage from dangling and unreferenced images.